package com.example.scanku

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts.StartIntentSenderForResult
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        setContent { MaterialTheme { App() } }
    }
}

private fun scanDir(ctx: Context) = File(ctx.filesDir, "scans").apply { mkdirs() }
private fun pagesDir(ctx: Context, base: String) = File(ctx.filesDir, "pages/$base").apply { mkdirs() }
private fun listScans(dir: File) =
    dir.listFiles { f -> f.extension == "pdf" }?.sortedByDescending { it.lastModified() } ?: emptyList()
private fun pageImages(ctx: Context, f: File) =
    pagesDir(ctx, f.nameWithoutExtension).listFiles()?.sortedBy { it.name } ?: emptyList()
private fun uriFor(ctx: Context, f: File): Uri =
    FileProvider.getUriForFile(ctx, "${ctx.packageName}.provider", f)

private fun runOcr(ctx: Context, images: List<File>, onDone: (String) -> Unit) {
    val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    val sb = StringBuilder()
    fun next(i: Int) {
        if (i >= images.size) { onDone(sb.toString().trim()); return }
        try {
            rec.process(InputImage.fromFilePath(ctx, Uri.fromFile(images[i])))
                .addOnSuccessListener { sb.append(it.text).append("\n\n"); next(i + 1) }
                .addOnFailureListener { next(i + 1) }
        } catch (e: Exception) { next(i + 1) }
    }
    next(0)
}

private fun shareFile(ctx: Context, f: File, mime: String, title: String) {
    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uriFor(ctx, f))
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }, title))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dir = remember { scanDir(ctx) }
    var files by remember { mutableStateOf(listScans(dir)) }
    var query by remember { mutableStateOf("") }
    var qrResult by remember { mutableStateOf<String?>(null) }
    var ocrText by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<File?>(null) }
    var deleteTarget by remember { mutableStateOf<File?>(null) }
    var passwordTarget by remember { mutableStateOf<File?>(null) }

    val scanLauncher = rememberLauncherForActivityResult(StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val res = GmsDocumentScanningResult.fromActivityResultIntent(r.data)
            val pdf = res?.pdf ?: return@rememberLauncherForActivityResult
            val base = "Scan_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            ctx.contentResolver.openInputStream(pdf.uri)?.use { i ->
                File(dir, "$base.pdf").outputStream().use { o -> i.copyTo(o) }
            }
            val pd = pagesDir(ctx, base)
            res.pages?.forEachIndexed { idx, page ->
                ctx.contentResolver.openInputStream(page.imageUri)?.use { i ->
                    File(pd, "page_%02d.jpg".format(idx + 1)).outputStream().use { o -> i.copyTo(o) }
                }
            }
            files = listScans(dir)
        }
    }

    fun startDocScan() {
        val opts = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(50)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_PDF, GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(opts).getStartScanIntent(ctx as Activity)
            .addOnSuccessListener { scanLauncher.launch(IntentSenderRequest.Builder(it).build()) }
            .addOnFailureListener { Toast.makeText(ctx, "Gagal membuka pemindai: ${it.message}", Toast.LENGTH_LONG).show() }
    }

    fun startQrScan() {
        GmsBarcodeScanning.getClient(ctx).startScan()
            .addOnSuccessListener { qrResult = it.rawValue }
            .addOnFailureListener { Toast.makeText(ctx, "Pindai QR dibatalkan", Toast.LENGTH_SHORT).show() }
    }

    val shown = files.filter { it.nameWithoutExtension.contains(query, ignoreCase = true) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("ScanKu") }) },
        floatingActionButton = {
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SmallFloatingActionButton(onClick = { startQrScan() }) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = "Pindai QR")
                }
                ExtendedFloatingActionButton(
                    onClick = { startDocScan() },
                    icon = { Icon(Icons.Default.DocumentScanner, null) },
                    text = { Text("Pindai Dokumen") }
                )
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                leadingIcon = { Icon(Icons.Default.Search, null) },
                placeholder = { Text("Cari dokumen") }, singleLine = true
            )
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (shown.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Belum ada dokumen.\nKetuk \"Pindai Dokumen\" untuk mulai.")
                }
            } else {
                LazyColumn {
                    items(shown, key = { it.absolutePath }) { f ->
                        var menu by remember { mutableStateOf(false) }
                        ListItem(
                            modifier = Modifier.clickable {
                                ctx.startActivity(Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(uriFor(ctx, f), "application/pdf")
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                })
                            },
                            leadingContent = { Icon(Icons.Default.PictureAsPdf, null) },
                            headlineContent = { Text(f.nameWithoutExtension) },
                            supportingContent = {
                                Text(SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date(f.lastModified())) +
                                    " • ${f.length() / 1024} KB")
                            },
                            trailingContent = {
                                Box {
                                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menu") }
                                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                        DropdownMenuItem(text = { Text("Bagikan PDF") },
                                            leadingIcon = { Icon(Icons.Default.Share, null) },
                                            onClick = { menu = false; shareFile(ctx, f, "application/pdf", "Bagikan PDF") })
                                        DropdownMenuItem(text = { Text("Bagikan sebagai gambar (JPG)") },
                                            leadingIcon = { Icon(Icons.Default.Image, null) },
                                            onClick = {
                                                menu = false
                                                val imgs = pageImages(ctx, f)
                                                if (imgs.isEmpty()) Toast.makeText(ctx, "Gambar tidak tersedia", Toast.LENGTH_SHORT).show()
                                                else ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                                                    type = "image/jpeg"
                                                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(imgs.map { uriFor(ctx, it) }))
                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                }, "Bagikan gambar"))
                                            })
                                        DropdownMenuItem(text = { Text("Ambil teks (OCR)") },
                                            leadingIcon = { Icon(Icons.Default.TextSnippet, null) },
                                            onClick = {
                                                menu = false
                                                val imgs = pageImages(ctx, f)
                                                if (imgs.isEmpty()) Toast.makeText(ctx, "Gambar tidak tersedia", Toast.LENGTH_SHORT).show()
                                                else { busy = true; runOcr(ctx, imgs) { t -> busy = false; ocrText = t.ifBlank { "(Tidak ada teks terdeteksi)" } } }
                                            })
                                        DropdownMenuItem(text = { Text("Kunci dengan password") },
                                            leadingIcon = { Icon(Icons.Default.Lock, null) },
                                            onClick = { menu = false; passwordTarget = f })
                                        DropdownMenuItem(text = { Text("Ganti nama") },
                                            leadingIcon = { Icon(Icons.Default.Edit, null) },
                                            onClick = { menu = false; renameTarget = f })
                                        DropdownMenuItem(text = { Text("Hapus") },
                                            leadingIcon = { Icon(Icons.Default.Delete, null) },
                                            onClick = { menu = false; deleteTarget = f })
                                    }
                                }
                            }
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }

    qrResult?.let { text ->
        AlertDialog(
            onDismissRequest = { qrResult = null },
            title = { Text("Hasil QR") }, text = { Text(text) },
            confirmButton = {
                TextButton(onClick = {
                    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("qr", text))
                    Toast.makeText(ctx, "Disalin", Toast.LENGTH_SHORT).show(); qrResult = null
                }) { Text("Salin") }
            },
            dismissButton = {
                if (text.startsWith("http")) TextButton(onClick = {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(text))); qrResult = null
                }) { Text("Buka link") }
            }
        )
    }

    ocrText?.let { text ->
        AlertDialog(
            onDismissRequest = { ocrText = null },
            title = { Text("Teks hasil OCR") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(text) } },
            confirmButton = {
                TextButton(onClick = {
                    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("ocr", text))
                    Toast.makeText(ctx, "Disalin", Toast.LENGTH_SHORT).show(); ocrText = null
                }) { Text("Salin") }
            },
            dismissButton = {
                TextButton(onClick = {
                    val tmp = File(ctx.cacheDir, "tmp").apply { mkdirs() }
                    val out = File(tmp, "hasil_ocr.txt").apply { writeText(text) }
                    shareFile(ctx, out, "text/plain", "Bagikan teks"); ocrText = null
                }) { Text("Bagikan .txt") }
            }
        )
    }

    passwordTarget?.let { f ->
        var pw by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { passwordTarget = null },
            title = { Text("Kunci PDF") },
            text = {
                Column {
                    Text("PDF akan meminta password saat dibuka. Jangan sampai lupa, password tidak bisa dipulihkan.")
                    OutlinedTextField(pw, { pw = it }, singleLine = true, label = { Text("Password") })
                }
            },
            confirmButton = {
                TextButton(enabled = pw.length >= 4, onClick = {
                    passwordTarget = null; busy = true
                    scope.launch {
                        val ok = withContext(Dispatchers.IO) {
                            try {
                                val tmp = File(f.parentFile, f.name + ".tmp")
                                PDDocument.load(f).use { doc ->
                                    val policy = StandardProtectionPolicy(pw + "_owner", pw, AccessPermission())
                                    policy.encryptionKeyLength = 128
                                    doc.protect(policy)
                                    doc.save(tmp)
                                }
                                tmp.copyTo(f, overwrite = true); tmp.delete(); true
                            } catch (e: Exception) { false }
                        }
                        busy = false
                        Toast.makeText(ctx, if (ok) "PDF dikunci" else "Gagal mengunci PDF", Toast.LENGTH_SHORT).show()
                        files = listScans(dir)
                    }
                }) { Text("Kunci") }
            },
            dismissButton = { TextButton(onClick = { passwordTarget = null }) { Text("Batal") } }
        )
    }

    renameTarget?.let { f ->
        var name by remember { mutableStateOf(f.nameWithoutExtension) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Ganti nama") },
            text = { OutlinedTextField(name, { name = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val clean = name.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
                    if (clean.isNotEmpty() && clean != f.nameWithoutExtension && !File(dir, "$clean.pdf").exists()) {
                        File(ctx.filesDir, "pages/${f.nameWithoutExtension}").renameTo(File(ctx.filesDir, "pages/$clean"))
                        f.renameTo(File(dir, "$clean.pdf"))
                    }
                    files = listScans(dir); renameTarget = null
                }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Batal") } }
        )
    }

    deleteTarget?.let { f ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Hapus dokumen?") }, text = { Text(f.name) },
            confirmButton = {
                TextButton(onClick = {
                    File(ctx.filesDir, "pages/${f.nameWithoutExtension}").deleteRecursively()
                    f.delete(); files = listScans(dir); deleteTarget = null
                }) { Text("Hapus") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Batal") } }
        )
    }
}
