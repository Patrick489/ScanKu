plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.scanku"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.scanku"
        minSdk = 21
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    // Pemindai dokumen (deteksi tepi, crop, filter, rotasi, multi-halaman, PDF) - gratis, tanpa iklan
    implementation("com.google.android.gms:play-services-mlkit-document-scanner:16.0.0-beta1")
    // Pemindai QR / barcode
    implementation("com.google.android.gms:play-services-code-scanner:16.1.0")
    // OCR di perangkat (ambil teks dari hasil scan)
    implementation("com.google.android.gms:play-services-mlkit-text-recognition:19.0.1")
    // Proteksi PDF dengan password
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
}
