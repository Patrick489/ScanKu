# ScanPro (Android, Kotlin + Jetpack Compose)

## Cara build
1. Install Android Studio (Koala atau lebih baru). Buka folder `ScanPro` ini → tunggu Gradle sync (butuh internet).
2. Colokkan HP (USB debugging aktif) atau pakai emulator Android 10+ (Google Play).
3. Tekan Run ▶. Untuk APK: Build → Build Bundle(s)/APK(s) → Build APK(s).
4. Buka tab "Saya" → isi kunci API Claude (https://console.anthropic.com) untuk Rumus, Solver AI, Set Pertanyaan.

## Catatan
- Scan/crop/filter memakai ML Kit Document Scanner, OCR memakai ML Kit (aksara Latin), terjemahan ML Kit (model diunduh saat pertama kali).
- Model ganti-latar pas foto diunduh Google Play Services saat pertama dipakai (butuh internet).
- Jika ada error saat build, kirim pesan error-nya ke Claude untuk diperbaiki.
