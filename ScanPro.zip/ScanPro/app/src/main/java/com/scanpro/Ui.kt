package com.scanpro

import android.graphics.Bitmap
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val Teal = Color(0xFF10B184)

@Composable
fun App(a: MainActivity) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Teal) else lightColorScheme(primary = Teal, background = Color(0xFFF2F6F5), surface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            BackHandler(a.screen !is Screen.Main) { a.screen = Screen.Main }
            Box(Modifier.fillMaxSize().systemBarsPadding()) {
                when (val s = a.screen) {
                    is Screen.Main -> MainScreen(a)
                    is Screen.Doc -> DocScreen(a, s.f, s.v)
                    is Screen.Text -> TextScreen(a, s)
                    is Screen.Sign -> SignScreen(a, s.f)
                    is Screen.Pages -> PagesScreen(a, s.f)
                    is Screen.Reorder -> ReorderScreen(a, s.f)
                    is Screen.Pick -> PickScreen(a, s)
                    is Screen.Count -> Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
                        TopBar(a, "CountCam"); Text("Terhitung: ${s.n} objek", fontSize = 22.sp)
                        Image(s.bmp.asImageBitmap(), null, Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth)
                    }
                }
                a.busy?.let {
                    Box(Modifier.fillMaxSize().background(Color(0x99000000)).clickable { }, Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) { CircularProgressIndicator(color = Color.White); Spacer(Modifier.height(10.dp)); Text(it, color = Color.White) }
                    }
                }
                a.dlg?.let { DlgHost(a, it) }
            }
        }
    }
}

@Composable
fun DlgHost(a: MainActivity, d: Dlg) {
    var t by remember(d) { mutableStateOf("") }
    AlertDialog(onDismissRequest = { a.dlg = null }, title = { Text(d.title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                d.items.forEachIndexed { i, s -> TextButton({ a.dlg = null; d.cb(i, "") }, Modifier.fillMaxWidth()) { Text(s, Modifier.fillMaxWidth()) } }
                if (d.hint != null) OutlinedTextField(t, { t = it }, placeholder = { Text(d.hint) }, singleLine = true,
                    visualTransformation = if (d.pass) PasswordVisualTransformation() else VisualTransformation.None)
            }
        },
        confirmButton = { if (d.hint != null) TextButton({ a.dlg = null; d.cb(0, t) }) { Text("OK") } },
        dismissButton = { TextButton({ a.dlg = null }) { Text("Batal") } })
}

@Composable
fun TopBar(a: MainActivity, title: String, action: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton({ a.screen = Screen.Main }) { Text("←", fontSize = 22.sp) }
        Text(title, Modifier.weight(1f), fontSize = 17.sp, maxLines = 1); action?.invoke()
    }
}

@Composable
fun Thumb(f: File, idx: Int, w: Int, mod: Modifier = Modifier) {
    val b by produceState<Bitmap?>(null, f.path, f.lastModified(), idx) { value = withContext(Dispatchers.IO) { runCatching { Pdf.page(f, idx, w) }.getOrNull() } }
    Box(mod.background(Color.White)) { b?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth) } }
}

@Composable
fun MainScreen(a: MainActivity) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        bottomBar = {
            NavigationBar {
                listOf("🏠" to "Beranda", "📄" to "File", "🧰" to "Alat", "👤" to "Saya").forEachIndexed { i, (e, n) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(e, fontSize = 20.sp) }, label = { Text(n) })
                }
            }
        },
        floatingActionButton = { FloatingActionButton({ a.tScan() }, containerColor = Teal, contentColor = Color.White, shape = CircleShape) { Text("📷", fontSize = 24.sp) } }
    ) { pad ->
        Box(Modifier.padding(pad)) { when (tab) { 0 -> Home(a); 1 -> Files(a); 2 -> Tools(a); else -> Me(a) } }
    }
}

@Composable
fun ToolGrid(tools: List<Tool>) {
    tools.chunked(4).forEach { row ->
        Row(Modifier.fillMaxWidth()) {
            row.forEach { t ->
                Column(Modifier.weight(1f).clickable { t.go() }.padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(52.dp).clip(RoundedCornerShape(17.dp)).background(Color(t.c).copy(alpha = .16f)), Alignment.Center) { Text(t.e, fontSize = 24.sp) }
                    Spacer(Modifier.height(4.dp)); Text(t.n, fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 2, lineHeight = 13.sp)
                }
            }
            repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}

@Composable
fun DocRow(a: MainActivity, f: File) {
    val pages = remember(f.path, f.lastModified()) { runCatching { Pdf.count(f) }.getOrDefault(0) }
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { a.open(f) }, shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Thumb(f, 0, 180, Modifier.width(56.dp).clip(RoundedCornerShape(8.dp)))
            Spacer(Modifier.width(12.dp))
            Column { Text(f.nameWithoutExtension, maxLines = 2, fontSize = 15.sp); Text(SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(f.lastModified())) + " · $pages hal.", fontSize = 12.sp, color = Color.Gray) }
        }
    }
}

@Composable
fun Home(a: MainActivity) {
    val all = a.sections.flatMap { it.second }
    val quick = listOf("Kartu ID", "Ekstrak Teks", "Tanda tangan", "Impor Gambar", "Impor File", "Scan Kode QR", "Solver AI", "Pas Foto").mapNotNull { n -> all.find { it.n == n } }
    val recent = remember(a.rev) { a.docs().take(5) }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(14.dp)) {
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Teal, Color(0xFF0A7F9A)))).padding(22.dp)) {
            Column { Text("ScanPro", color = Color.White, fontSize = 26.sp); Text("Pindai, edit, tanda tangan & konversi dokumen", color = Color.White.copy(alpha = .85f)) }
        }
        Spacer(Modifier.height(14.dp)); ToolGrid(quick)
        Text("Terkini", fontSize = 18.sp, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))
        if (recent.isEmpty()) Text("Belum ada dokumen. Ketuk tombol kamera untuk mulai.", color = Color.Gray)
        recent.forEach { DocRow(a, it) }
        Spacer(Modifier.height(80.dp))
    }
}

@Composable
fun Files(a: MainActivity) {
    var signed by remember { mutableStateOf(false) }
    val list = remember(a.rev, signed) { a.docs(signed) }
    LazyColumn(Modifier.padding(14.dp)) {
        item {
            Row(Modifier.padding(bottom = 8.dp)) {
                FilterChip(!signed, { signed = false }, { Text("Semua (${a.docs().size})") }); Spacer(Modifier.width(8.dp))
                FilterChip(signed, { signed = true }, { Text("✍️ Ditandatangani") })
            }
        }
        items(list) { DocRow(a, it) }
        item { Spacer(Modifier.height(90.dp)) }
    }
}

@Composable
fun Tools(a: MainActivity) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(14.dp)) {
        Text("Alat", fontSize = 24.sp)
        a.sections.forEach { (n, t) -> Text(n, fontSize = 16.sp, modifier = Modifier.padding(top = 16.dp, bottom = 6.dp)); ToolGrid(t) }
        Spacer(Modifier.height(80.dp))
    }
}

@Composable
fun Me(a: MainActivity) {
    var k by remember { mutableStateOf(a.prefs.getString("key", "").orEmpty()) }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Saya", fontSize = 24.sp)
        Text("Kunci API Claude", Modifier.padding(top = 16.dp), fontSize = 16.sp)
        Text("Dipakai oleh Rumus, Solver AI, dan Set Pertanyaan. Disimpan hanya di perangkat ini.", fontSize = 12.sp, color = Color.Gray)
        OutlinedTextField(k, { k = it; a.prefs.edit().putString("key", it.trim()).apply() }, Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true, visualTransformation = PasswordVisualTransformation(), placeholder = { Text("sk-ant-…") })
        Text("${a.docs().size} dokumen tersimpan di perangkat", Modifier.padding(top = 20.dp), color = Color.Gray)
    }
}

@Composable
fun DocScreen(a: MainActivity, f: File, v: Int) {
    val n = remember(f.path, v) { Pdf.count(f) }
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        TopBar(a, f.nameWithoutExtension) { TextButton({ a.docMenu(f) }) { Text("⋯ Menu", fontSize = 16.sp) } }
        LazyColumn(Modifier.weight(1f)) {
            items(n) { i -> Column(Modifier.padding(bottom = 10.dp)) { Thumb(f, i, 900, Modifier.clip(RoundedCornerShape(6.dp))); Text("Halaman ${i + 1}", fontSize = 12.sp, color = Color.Gray) } }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ a.share(f, "application/pdf") }, Modifier.weight(1f)) { Text("📤 Bagikan") }
            OutlinedButton({ a.docMenu(f) }, Modifier.weight(1f)) { Text("Lainnya ⋯") }
        }
    }
}

@Composable
fun TextScreen(a: MainActivity, s: Screen.Text) {
    val ctx = LocalContextCompat()
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        TopBar(a, s.title)
        SelectionContainer(Modifier.weight(1f).verticalScroll(rememberScrollState())) { Text(s.text, fontSize = 15.sp) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            Button({ (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("t", s.text)); a.toast("Disalin") }) { Text("Salin") }
            OutlinedButton({ ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, s.text), "Bagikan")) }) { Text("Bagikan") }
            if (s.link != null && s.link.startsWith("http")) OutlinedButton({ ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(s.link))) }) { Text("Buka") }
        }
    }
}
@Composable fun LocalContextCompat(): Context = androidx.compose.ui.platform.LocalContext.current

@Composable
fun SignScreen(a: MainActivity, f: File) {
    val n = remember(f.path) { Pdf.count(f) }
    var idx by remember { mutableStateOf<Int?>(if (n == 1) 0 else null) }
    var sig by remember { mutableStateOf<Bitmap?>(null) }
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        TopBar(a, "Tanda tangan")
        if (idx == null) {
            Text("Pilih halaman yang akan ditandatangani", Modifier.padding(bottom = 8.dp))
            repeat(n) { i -> Row(Modifier.fillMaxWidth().clickable { idx = i }.padding(6.dp), verticalAlignment = Alignment.CenterVertically) { Thumb(f, i, 200, Modifier.width(70.dp)); Text("  Halaman ${i + 1}") } }
        } else if (sig == null) {
            val strokes = remember { mutableStateListOf<List<Offset>>() }
            var cur by remember { mutableStateOf<List<Offset>>(emptyList()) }
            var sz by remember { mutableStateOf(IntSize.Zero) }
            Text("Gambar tanda tangan Anda", Modifier.padding(bottom = 8.dp))
            Box(Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(16.dp)).background(Color.White).onSizeChanged { sz = it }
                .pointerInput(Unit) { detectDragGestures(onDragStart = { cur = listOf(it) }, onDragEnd = { strokes.add(cur); cur = emptyList() }, onDrag = { ch, _ -> ch.consume(); cur = cur + ch.position }) }) {
                Canvas(Modifier.fillMaxSize()) { (strokes + listOf(cur)).forEach { s -> for (i in 1 until s.size) drawLine(Color(0xFF0A2A6C), s[i - 1], s[i], 6f, StrokeCap.Round) } }
            }
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ strokes.clear() }) { Text("Hapus") }
                Button({ if (strokes.isNotEmpty()) sig = Img.sigBitmap(strokes.map { s -> s.map { it.x to it.y } }, sz.width, sz.height) }) { Text("Lanjut") }
            }
        } else {
            val page by produceState<Bitmap?>(null, f.path) { value = withContext(Dispatchers.IO) { Pdf.page(f, idx!!, 1240) } }
            var isz by remember { mutableStateOf(IntSize.Zero) }
            Text("Ketuk posisi tanda tangan pada halaman", Modifier.padding(bottom = 8.dp))
            page?.let { pg ->
                Image(pg.asImageBitmap(), null, Modifier.fillMaxWidth().onSizeChanged { isz = it }.pointerInput(Unit) {
                    detectTapGestures { o ->
                        val fx = o.x / isz.width; val fy = o.y / isz.height
                        a.work("Menempel tanda tangan…") {
                            val out = withContext(Dispatchers.IO) {
                                val ps = Pdf.all(f).toMutableList(); ps[idx!!] = Img.stamp(ps[idx!!], sig!!, fx, fy)
                                File(a.signDir, f.nameWithoutExtension + " (ttd).pdf").also { Pdf.build(ps, it) }
                            }
                            a.rev++; a.open(out)
                        }
                    }
                }, contentScale = ContentScale.FillWidth)
            }
        }
    }
}

@Composable
fun PagesScreen(a: MainActivity, f: File) {
    val n = remember(f.path) { Pdf.count(f) }
    val sel = remember { mutableStateListOf<Int>() }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        TopBar(a, "Pisah halaman – centang halaman")
        LazyColumn(Modifier.weight(1f)) {
            items(n) { i ->
                Row(Modifier.fillMaxWidth().clickable { if (i in sel) sel.remove(i) else sel.add(i) }.padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(i in sel, { if (it) sel.add(i) else sel.remove(i) }); Thumb(f, i, 240, Modifier.width(90.dp)); Text("  Halaman ${i + 1}")
                }
            }
        }
        Button({
            if (sel.isEmpty()) a.toast("Pilih halaman") else a.work("Membuat dokumen…") {
                a.open(withContext(Dispatchers.IO) { val all = Pdf.all(f); a.saveDoc(f.nameWithoutExtension + " (pisah)", sel.sorted().map { all[it] }) })
            }
        }, Modifier.fillMaxWidth()) { Text("Buat dokumen dari ${sel.size} halaman") }
    }
}

@Composable
fun ReorderScreen(a: MainActivity, f: File) {
    val order = remember { mutableStateListOf<Int>().also { l -> repeat(Pdf.count(f)) { l.add(it) } } }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        TopBar(a, "Urutkan ulang halaman")
        LazyColumn(Modifier.weight(1f)) {
            items(order.size) { pos ->
                Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Thumb(f, order[pos], 240, Modifier.width(80.dp)); Text("  Halaman ${order[pos] + 1}", Modifier.weight(1f))
                    TextButton({ if (pos > 0) { val t = order[pos]; order[pos] = order[pos - 1]; order[pos - 1] = t } }) { Text("▲") }
                    TextButton({ if (pos < order.size - 1) { val t = order[pos]; order[pos] = order[pos + 1]; order[pos + 1] = t } }) { Text("▼") }
                    TextButton({ if (order.size > 1) order.removeAt(pos) }) { Text("🗑") }
                }
            }
        }
        Button({
            a.work("Menyimpan…") {
                withContext(Dispatchers.IO) { val all = Pdf.all(f); val t = File(a.cacheDir, "o.pdf"); Pdf.build(order.map { all[it] }, t); t.copyTo(f, true) }
                a.rev++; a.open(f)
            }
        }, Modifier.fillMaxWidth()) { Text("Simpan urutan") }
    }
}

@Composable
fun PickScreen(a: MainActivity, s: Screen.Pick) {
    val list = remember { a.docs() }
    val sel = remember { mutableStateListOf<File>() }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        TopBar(a, s.title)
        LazyColumn(Modifier.weight(1f)) {
            items(list) { f ->
                Row(Modifier.fillMaxWidth().clickable {
                    if (s.multi) { if (f in sel) sel.remove(f) else sel.add(f) } else { a.screen = Screen.Main; s.cb(listOf(f)) }
                }, verticalAlignment = Alignment.CenterVertically) {
                    if (s.multi) Checkbox(f in sel, { if (it) sel.add(f) else sel.remove(f) })
                    Box(Modifier.weight(1f)) { DocRowStatic(f) }
                }
            }
        }
        if (s.multi) Button({ a.screen = Screen.Main; s.cb(sel.toList()) }, Modifier.fillMaxWidth()) { Text("Lanjut (${sel.size})") }
    }
}

@Composable
fun DocRowStatic(f: File) {
    Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Thumb(f, 0, 160, Modifier.width(48.dp)); Spacer(Modifier.width(10.dp)); Text(f.nameWithoutExtension, maxLines = 2)
    }
}
