package com.scanpro

import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Base64
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs

object Ai {
    const val MODEL = "claude-sonnet-5-5"
    suspend fun ask(key: String, prompt: String, b: Bitmap): String = withContext(Dispatchers.IO) {
        val bo = ByteArrayOutputStream(); Img.scale(b, 1600).compress(Bitmap.CompressFormat.JPEG, 85, bo)
        val img = JSONObject().put("type", "image").put("source", JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)))
        val body = JSONObject().put("model", MODEL).put("max_tokens", 3000).put("messages", JSONArray().put(JSONObject().put("role", "user")
            .put("content", JSONArray().put(img).put(JSONObject().put("type", "text").put("text", prompt)))))
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 30000; c.readTimeout = 120000
        c.setRequestProperty("x-api-key", key); c.setRequestProperty("anthropic-version", "2023-06-01"); c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = c.responseCode in 200..299
        val txt = (if (ok) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        if (!ok) throw Exception("API ${c.responseCode}: ${txt.take(200)}")
        val a = JSONObject(txt).getJSONArray("content")
        (0 until a.length()).map { a.getJSONObject(it) }.filter { it.optString("type") == "text" }.joinToString("\n") { it.getString("text") }
    }
}

object Ocr {
    private val rec by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    suspend fun text(b: Bitmap): String = rec.process(InputImage.fromBitmap(b, 0)).await().text

    suspend fun rows(b: Bitmap): List<List<String>> {
        val lines = rec.process(InputImage.fromBitmap(b, 0)).await().textBlocks.flatMap { it.lines }.sortedBy { it.boundingBox?.centerY() ?: 0 }
        val rows = mutableListOf<MutableList<com.google.mlkit.vision.text.Text.Line>>()
        for (l in lines) {
            val cy = l.boundingBox?.centerY() ?: 0; val h = l.boundingBox?.height() ?: 10
            val last = rows.lastOrNull()
            if (last != null && abs((last[0].boundingBox?.centerY() ?: 0) - cy) < h * 0.6) last.add(l) else rows.add(mutableListOf(l))
        }
        return rows.map { r -> r.sortedBy { it.boundingBox?.left ?: 0 }.map { it.text } }
    }

    suspend fun translate(text: String, target: String): String {
        val tag = LanguageIdentification.getClient().identifyLanguage(text).await()
        val src = TranslateLanguage.fromLanguageTag(tag) ?: throw Exception("Bahasa sumber tidak dikenali")
        if (src == target) return text
        val t = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(target).build())
        try { t.downloadModelIfNeeded().await(); return t.translate(text).await() } finally { t.close() }
    }

    suspend fun detect(b: Bitmap): List<Rect> {
        val d = ObjectDetection.getClient(ObjectDetectorOptions.Builder().setDetectorMode(ObjectDetectorOptions.SINGLE_IMAGE_MODE).enableMultipleObjects().build())
        return d.process(InputImage.fromBitmap(b, 0)).await().map { it.boundingBox }
    }

    suspend fun segment(b: Bitmap): Bitmap? {
        val s = SubjectSegmentation.getClient(SubjectSegmenterOptions.Builder().enableForegroundBitmap().build())
        return s.process(InputImage.fromBitmap(b, 0)).await().foregroundBitmap
    }
}
