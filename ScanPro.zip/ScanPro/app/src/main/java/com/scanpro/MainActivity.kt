package com.scanpro

import android.Manifest
import android.content.Intent
import android.graphics.*
import android.location.Geocoder
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.print.PrintManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import com.google.mlkit.nl.translate.TranslateLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class Screen {
    object Main : Screen()
    data class Doc(val f: File, val v: Int = 0) : Screen()
    data class Text(val title: String, val text: String, val link: String? = null) : Screen()
    data class Sign(val f: File) : Screen()
    data class Pages(val f: File) : Screen()
    data class Reorder(val f: File) : Screen()
    data class Pick(val title: String, val multi: Boolean, val cb: (List<File>) -> Unit) : Screen()
    data class Count(val bmp: Bitmap, val n: Int) : Screen()
}

class Dlg(val title: String, val items: List<String> = emptyList(), val hint: String? = null, val pass: Boolean = false, val cb: (Int, String) -> Unit)
class Tool(val e: String, val n: String, val c: Long, val go: () -> Unit)

class MainActivity : ComponentActivity() {
    var screen by mutableStateOf<Screen>(Screen.Main)
    var dlg by mutableStateOf<Dlg?>(null)
    var busy by mutableStateOf<String?>(null)
    var rev by mutableIntStateOf(0)
    val docsDir by lazy { File(filesDir, "docs").apply { mkdirs() } }
    val signDir by lazy { File(docsDir, "signed").apply { mkdirs() } }
    val prefs by lazy { getSharedPreferences("sp", 0) }

    private var onUris: ((List<Uri>) -> Unit)? = null
    private var camFile: File? = null
    private var onShot: ((Boolean) -> Unit)? = null
    private var onPerm: (() -> Unit)? = null
    private val pickImgs = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { onUris?.invoke(it) }
    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { onUris?.invoke(listOfNotNull(it)) }
    private val takePic = registerForActivityResult(ActivityResultContracts.TakePicture()) { onShot?.invoke(it) }
    private val scanRes = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        val s = GmsDocumentScanningResult.fromActivityResultIntent(r.data)
        onUris?.invoke(s?.pages?.map { it.imageUri }.orEmpty())
    }
    private val perm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { onPerm?.invoke() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App(this) }
    }

    // ---------- util ----------
    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    fun work(msg: String, f: suspend () -> Unit) {
        lifecycleScope.launch { busy = msg; try { f() } catch (e: Throwable) { toast("Gagal: ${e.message}") } finally { busy = null } }
    }
    fun docs(signed: Boolean = false): List<File> =
        (if (signed) signDir else docsDir).listFiles { f -> f.isFile && f.name.endsWith(".pdf") }.orEmpty().sortedByDescending { it.lastModified() }
    private fun stampName(p: String) = "$p " + SimpleDateFormat("dd-MM-yy HH.mm.ss", Locale.getDefault()).format(Date())
    fun saveDoc(prefix: String, pages: List<Bitmap>, dir: File = docsDir): File {
        val f = File(dir, stampName(prefix) + ".pdf"); Pdf.build(pages, f); rev++; return f
    }
    fun key(): String? {
        val k = prefs.getString("key", "").orEmpty()
        if (k.isBlank()) { toast("Isi kunci API Claude di tab Saya dulu"); return null }
        return k
    }
    fun share(f: File, mime: String) {
        val u = FileProvider.getUriForFile(this, "$packageName.fp", f)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Bagikan"))
    }
    private fun decode(src: ImageDecoder.Source): Bitmap = ImageDecoder.decodeBitmap(src) { d, info, _ ->
        d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val m = maxOf(info.size.width, info.size.height); if (m > 2600) d.setTargetSampleSize(m / 2600 + 1)
    }
    private fun decodeAll(u: List<Uri>, cb: (List<Bitmap>) -> Unit) = lifecycleScope.launch {
        cb(withContext(Dispatchers.IO) { u.map { decode(ImageDecoder.createSource(contentResolver, it)) } })
    }

    // ---------- sumber gambar ----------
    fun scanDoc(limit: Int, cb: (List<Bitmap>) -> Unit) {
        val o = GmsDocumentScannerOptions.Builder().setGalleryImportAllowed(true).setPageLimit(limit)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG).setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL).build()
        onUris = { decodeAll(it, cb) }
        GmsDocumentScanning.getClient(o).getStartScanIntent(this)
            .addOnSuccessListener { scanRes.launch(IntentSenderRequest.Builder(it).build()) }
            .addOnFailureListener { toast("Scanner: ${it.message}") }
    }
    fun shoot(cb: (Bitmap?) -> Unit) {
        val f = File(cacheDir, "cam.jpg"); camFile = f
        onShot = { ok -> if (ok) lifecycleScope.launch { cb(withContext(Dispatchers.IO) { decode(ImageDecoder.createSource(f)) }) } else cb(null) }
        takePic.launch(FileProvider.getUriForFile(this, "$packageName.fp", f))
    }
    fun gallery(cb: (List<Bitmap>) -> Unit) { onUris = { decodeAll(it, cb) }; pickImgs.launch("image/*") }
    fun getBitmaps(multi: Boolean, cb: (List<Bitmap>) -> Unit) {
        dlg = Dlg("Ambil gambar", listOf("📄 Scan dokumen (potong otomatis)", "📷 Kamera", "🖼️ Galeri")) { i, _ ->
            when (i) {
                0 -> scanDoc(if (multi) 100 else 1, cb)
                1 -> shoot { cb(listOfNotNull(it)) }
                else -> gallery(cb)
            }
        }
    }
    fun pickDocs(title: String, multi: Boolean, cb: (List<File>) -> Unit) {
        if (docs().isEmpty()) toast("Belum ada dokumen. Scan dulu!") else screen = Screen.Pick(title, multi, cb)
    }
    fun open(f: File) { screen = Screen.Doc(f, (System.nanoTime() % 100000).toInt()) }

    // ---------- tool ----------
    fun tScan(prefix: String = "Scan", limit: Int = 100) = scanDoc(limit) { bs ->
        if (bs.isNotEmpty()) work("Menyimpan…") { open(withContext(Dispatchers.IO) { saveDoc(prefix, bs) }) }
    }
    fun tFilter(mode: String, prefix: String) = getBitmaps(true) { bs ->
        if (bs.isNotEmpty()) work("Memproses…") { open(withContext(Dispatchers.IO) { saveDoc(prefix, bs.map { Img.filter(it, mode) }) }) }
    }
    fun tId() = scanDoc(2) { bs ->
        if (bs.isNotEmpty()) work("Membuat…") {
            open(withContext(Dispatchers.IO) {
                val o = Bitmap.createBitmap(1240, 1754, Bitmap.Config.ARGB_8888); val c = Canvas(o); c.drawColor(Color.WHITE)
                var y = 140f
                bs.forEach { b -> val s = 900f / b.width; val h = b.height * s; c.drawBitmap(b, null, RectF((1240 - 900) / 2f, y, (1240 + 900) / 2f, y + h), Paint(Paint.FILTER_BITMAP_FLAG)); y += h + 100 }
                saveDoc("Kartu ID", listOf(o))
            })
        }
    }
    fun tOcr() = getBitmaps(true) { bs ->
        if (bs.isNotEmpty()) work("Mengenali teks…") { screen = Screen.Text("Ekstrak Teks", bs.joinToString("\n\n") { Ocr.text(it) }.ifBlank { "(Tidak ada teks terdeteksi)" }) }
    }
    fun tAi(title: String, prompt: String) = getBitmaps(false) { bs ->
        val k = key()
        if (k != null && bs.isNotEmpty()) work("Menganalisis dengan Claude…") { screen = Screen.Text(title, Ai.ask(k, prompt, bs[0])) }
    }
    fun tTranslate() {
        val names = listOf("Indonesia", "Inggris", "Jepang", "Mandarin", "Arab")
        val codes = listOf(TranslateLanguage.INDONESIAN, TranslateLanguage.ENGLISH, TranslateLanguage.JAPANESE, TranslateLanguage.CHINESE, TranslateLanguage.ARABIC)
        dlg = Dlg("Terjemahkan ke…", names) { i, _ ->
            getBitmaps(false) { bs ->
                if (bs.isNotEmpty()) work("Mengenali & menerjemahkan…") {
                    val t = Ocr.text(bs[0]); if (t.isBlank()) throw Exception("Teks tidak terdeteksi")
                    screen = Screen.Text("Terjemahan → ${names[i]}", Ocr.translate(t, codes[i]) + "\n\n— Teks asli —\n" + t)
                }
            }
        }
    }
    fun tQr() {
        GmsBarcodeScanning.getClient(this).startScan()
            .addOnSuccessListener { screen = Screen.Text("Hasil Scan Kode", it.rawValue.orEmpty(), it.rawValue) }
            .addOnFailureListener { toast("QR: ${it.message}") }
    }
    private fun place(): String = try {
        val lm = getSystemService(LocationManager::class.java)
        val l = lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }
        if (l == null) "" else (Geocoder(this, Locale("id")).getFromLocation(l.latitude, l.longitude, 1)?.firstOrNull()?.getAddressLine(0)
            ?: "%.5f, %.5f".format(l.latitude, l.longitude))
    } catch (e: Throwable) { "" }
    fun tStamp() {
        onPerm = {
            shoot { b ->
                if (b != null) work("Menambah stempel…") {
                    val lines = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale("id")).format(Date()) + "\n" + withContext(Dispatchers.IO) { place() }
                    open(withContext(Dispatchers.IO) { Pdf.saveGallery(this@MainActivity, Img.timestamp(b, lines), stampName("Stempel")); saveDoc("Stempel", listOf(Img.timestamp(b, lines))) })
                }
            }
        }
        perm.launch(Manifest.permission.ACCESS_FINE_LOCATION)
    }
    fun tPas() {
        val sz = listOf("25×35 mm" to (25 to 35), "35×45 mm (Visa Indonesia)" to (35 to 45), "51×51 mm (Paspor AS)" to (51 to 51), "35×49 mm" to (35 to 49))
        val bgs = listOf("Merah" to Color.rgb(219, 31, 38), "Biru" to Color.rgb(30, 91, 216), "Putih" to Color.WHITE, "Tetap (tanpa ganti latar)" to 0)
        dlg = Dlg("Ukuran foto", sz.map { it.first }) { i, _ ->
            val (w, h) = sz[i].second
            dlg = Dlg("Warna latar", bgs.map { it.first }) { j, _ ->
                getBitmaps(false) { bs ->
                    if (bs.isNotEmpty()) work("Membuat pas foto…") {
                        val src = Img.scale(bs[0], 2000)
                        val bg = if (j == 3) null else bgs[j].second
                        val fg = if (bg != null) Ocr.segment(src) else null
                        open(withContext(Dispatchers.IO) { val p = Img.passPhoto(src, fg, bg, w, h); saveDoc("Pas Foto", listOf(p, Img.sheet(p, w, h))) })
                    }
                }
            }
        }
    }
    fun tImportImage() = getBitmaps(true) { bs -> if (bs.isNotEmpty()) work("Mengimpor…") { open(withContext(Dispatchers.IO) { saveDoc("Impor", bs) }) } }
    fun tImportFile() {
        onUris = { us ->
            val u = us.firstOrNull()
            if (u != null) work("Mengimpor…") {
                open(withContext(Dispatchers.IO) {
                    val t = contentResolver.getType(u).orEmpty()
                    if (t.contains("pdf")) {
                        val f = File(docsDir, stampName("Impor") + ".pdf"); contentResolver.openInputStream(u)!!.use { i -> f.outputStream().use { i.copyTo(it) } }; rev++; f
                    } else {
                        val f = File(docsDir, stampName("Impor") + ".pdf")
                        Pdf.textToPdf(contentResolver.openInputStream(u)!!.use { Office.readText(it, t) }, f); rev++; f
                    }
                })
            }
        }
        pickFile.launch(arrayOf("application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.openxmlformats-officedocument.presentationml.presentation"))
    }
    fun tExportScan(kind: String) = getBitmaps(true) { bs ->
        if (bs.isNotEmpty()) work("Menyimpan…") { export(withContext(Dispatchers.IO) { saveDoc("Scan", bs) }, kind) }
    }
    fun export(f: File, kind: String) = work("Mengonversi…") {
        val out = withContext(Dispatchers.IO) {
            val ps = Pdf.all(f, 1400); val base = f.nameWithoutExtension
            when (kind) {
                "docx" -> File(cacheDir, "$base.docx").also { Office.docx(ps.map { Ocr.text(it) }, it) }
                "xlsx" -> File(cacheDir, "$base.xlsx").also { o -> Office.xlsx(ps.flatMap { Ocr.rows(it) + listOf(emptyList()) }, o) }
                else -> File(cacheDir, "$base.pptx").also { Office.pptx(ps, it) }
            }
        }
        share(out, "application/octet-stream")
    }
    fun rebuild(f: File, tr: (Bitmap) -> Bitmap) = work("Memproses…") {
        withContext(Dispatchers.IO) { val t = File(cacheDir, "w.pdf"); Pdf.build(Pdf.all(f).map(tr), t); t.copyTo(f, true) }
        rev++; open(f)
    }
    fun toImages(f: File, long: Boolean) = work("Menyimpan gambar…") {
        withContext(Dispatchers.IO) {
            val ps = Pdf.all(f, 1500)
            if (long) {
                val o = Bitmap.createBitmap(1500, ps.sumOf { it.height }, Bitmap.Config.ARGB_8888); val c = Canvas(o); var y = 0f
                ps.forEach { c.drawBitmap(it, 0f, y, null); y += it.height }
                Pdf.saveGallery(this@MainActivity, o, f.nameWithoutExtension + " panjang")
            } else ps.forEachIndexed { i, b -> Pdf.saveGallery(this@MainActivity, b, f.nameWithoutExtension + " ${i + 1}") }
        }
        toast("Tersimpan di Galeri › Pictures/ScanPro")
    }
    fun compress(f: File) {
        dlg = Dlg("Tingkat kompresi", listOf("Ringan", "Sedang", "Tinggi")) { i, _ ->
            work("Mengompres…") {
                val (px, q) = listOf(1500 to 75, 1200 to 55, 900 to 35)[i]
                val n = withContext(Dispatchers.IO) { val o = File(docsDir, f.nameWithoutExtension + " (kompres).pdf"); Pdf.build(Pdf.all(f, px).map { Img.jpegRound(it, px, q) }, o, px); o }
                rev++; toast("${f.length() / 1024} KB → ${n.length() / 1024} KB"); open(n)
            }
        }
    }
    fun lock(f: File) {
        dlg = Dlg("Kata sandi PDF", hint = "Kata sandi", pass = true) { _, p ->
            if (p.isNotBlank()) work("Mengunci…") {
                val o = File(cacheDir, f.nameWithoutExtension + " (terkunci).pdf")
                withContext(Dispatchers.IO) { Pdf.lock(this@MainActivity, f, o, p) }; share(o, "application/pdf")
            }
        }
    }
    fun watermark(f: File) { dlg = Dlg("Teks tanda air", hint = "Mis. RAHASIA") { _, t -> if (t.isNotBlank()) rebuild(f) { Img.watermark(it, t) } } }
    fun rename(f: File) {
        dlg = Dlg("Ganti nama", hint = f.nameWithoutExtension) { _, t ->
            if (t.isNotBlank()) { val n = File(f.parentFile, t.replace("/", "-") + ".pdf"); f.renameTo(n); rev++; open(n) }
        }
    }
    fun print(f: File) { (getSystemService(PRINT_SERVICE) as PrintManager).print(f.name, Pdf.Printer(f), null) }
    fun delete(f: File) { f.delete(); rev++; screen = Screen.Main }
    fun docOcr(f: File) = work("Mengenali teks…") { screen = Screen.Text(f.nameWithoutExtension, withContext(Dispatchers.IO) { Pdf.all(f, 1400).joinToString("\n\n") { Ocr.text(it) } }.ifBlank { "(Tidak ada teks)" }) }

    fun docMenu(f: File) {
        val items = listOf("📤 Bagikan PDF", "✏️ Ganti nama", "✍️ Tanda tangan", "💧 Tanda air", "🔒 Kunci (kata sandi)", "🗜 Kompres", "✂️ Pisah halaman", "↕️ Urutkan halaman",
            "📝 Ke Word", "📊 Ke Excel", "📽 Ke PPT", "🖼 Simpan ke Galeri", "🧵 Gambar panjang", "🔤 Ekstrak teks", "🖨 Cetak", "🗑 Hapus")
        dlg = Dlg("Menu dokumen", items) { i, _ ->
            when (i) {
                0 -> share(f, "application/pdf"); 1 -> rename(f); 2 -> screen = Screen.Sign(f); 3 -> watermark(f); 4 -> lock(f); 5 -> compress(f)
                6 -> screen = Screen.Pages(f); 7 -> screen = Screen.Reorder(f); 8 -> export(f, "docx"); 9 -> export(f, "xlsx"); 10 -> export(f, "pptx")
                11 -> toImages(f, false); 12 -> toImages(f, true); 13 -> docOcr(f); 14 -> print(f); else -> delete(f)
            }
        }
    }

    val sections: List<Pair<String, List<Tool>>> by lazy {
        listOf(
            "Scan" to listOf(
                Tool("🪪", "Kartu ID", 0xFF2A9D8F) { tId() }, Tool("🔤", "Ekstrak Teks", 0xFF10B184) { tOcr() },
                Tool("👤", "Pas Foto", 0xFF3B82F6) { tPas() }, Tool("∑", "Rumus", 0xFF10B184) { tAi("Rumus (LaTeX)", "Salin semua rumus matematika pada gambar ke LaTeX, satu rumus per baris, beri nomor. Sertakan juga teks di sekitarnya secara singkat.") },
                Tool("🌐", "Penerjemahan foto", 0xFF6366F1) { tTranslate() }, Tool("📖", "Buku", 0xFF0EA5E9) { tScan("Buku") },
                Tool("📽", "Slide", 0xFFEF6C4D) { tScan("Slide") }, Tool("📋", "Papan Tulis", 0xFF06B6D4) { tFilter("bersih", "Papan Tulis") },
                Tool("🕒", "Stempel waktu", 0xFF2563EB) { tStamp() }),
            "Impor" to listOf(Tool("🖼️", "Impor Gambar", 0xFF10B184) { tImportImage() }, Tool("📂", "Impor File", 0xFF3B82F6) { tImportFile() }),
            "Konversi" to listOf(
                Tool("📝", "Ke Word", 0xFF3B82F6) { tExportScan("docx") }, Tool("📊", "Ke Excel", 0xFF22C55E) { tExportScan("xlsx") },
                Tool("📽", "Ke PPT", 0xFFEF6C4D) { tExportScan("pptx") },
                Tool("🖼", "PDF ke Gambar", 0xFF14B8A6) { pickDocs("PDF ke Gambar", false) { toImages(it[0], false) } },
                Tool("🧵", "PDF ke Gambar Panjang", 0xFF0EA5E9) { pickDocs("PDF ke Gambar Panjang", false) { toImages(it[0], true) } }),
            "Edit" to listOf(
                Tool("✍️", "Tanda tangan", 0xFF16A085) { pickDocs("Pilih dokumen", false) { screen = Screen.Sign(it[0]) } },
                Tool("💧", "Tambah Tanda Air", 0xFF3B82F6) { pickDocs("Pilih dokumen", false) { watermark(it[0]) } },
                Tool("🧹", "Hapus Cerdas", 0xFF22C55E) { tFilter("bersih", "Bersih") }, Tool("🖍", "Hapus Penanda", 0xFF6366F1) { tFilter("tinta", "Tanpa Penanda") },
                Tool("🩹", "Pulihkan Foto", 0xFFEF6C4D) { tFilter("pulih", "Pulih") },
                Tool("🗂", "Gabungkan File", 0xFF6366F1) { pickDocs("Pilih ≥2 dokumen", true) { fs -> if (fs.size < 2) toast("Pilih minimal 2") else work("Menggabungkan…") { open(withContext(Dispatchers.IO) { saveDoc("Gabungan", fs.flatMap { Pdf.all(it) }) }) } } },
                Tool("✂️", "Pisah Halaman PDF", 0xFF3B82F6) { pickDocs("Pilih dokumen", false) { screen = Screen.Pages(it[0]) } },
                Tool("↕️", "Urutkan Ulang Halaman", 0xFF6366F1) { pickDocs("Pilih dokumen", false) { screen = Screen.Reorder(it[0]) } },
                Tool("🔒", "Kunci", 0xFF16A34A) { pickDocs("Pilih dokumen", false) { lock(it[0]) } },
                Tool("🗜", "Kompres", 0xFF6366F1) { pickDocs("Pilih dokumen", false) { compress(it[0]) } }),
            "Utilitas" to listOf(
                Tool("✨", "Solver AI", 0xFF10B184) { tAi("Solver AI", "Selesaikan soal/masalah pada gambar. Jelaskan langkah demi langkah dalam bahasa Indonesia dan berikan jawaban akhir.") },
                Tool("🔢", "CountCam", 0xFF3B82F6) { getBitmaps(false) { bs -> if (bs.isNotEmpty()) work("Menghitung…") { val r = Ocr.detect(Img.scale(bs[0], 1600)); screen = Screen.Count(Img.boxes(Img.scale(bs[0], 1600), r), r.size) } } },
                Tool("🖨", "Cetak", 0xFF14B8A6) { pickDocs("Pilih dokumen", false) { print(it[0]) } },
                Tool("📲", "Scan Kode QR", 0xFF10B184) { tQr() },
                Tool("📚", "Set Pertanyaan", 0xFF6366F1) { tAi("Set Pertanyaan", "Gambar berisi kumpulan soal. Tulis ulang setiap soal lalu berikan jawaban dan penjelasan singkat, dalam bahasa Indonesia.") })
        )
    }
}
