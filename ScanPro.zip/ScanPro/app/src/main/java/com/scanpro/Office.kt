package com.scanpro

import android.graphics.Bitmap
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object Office {
    private const val X = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
    private const val RN = "http://schemas.openxmlformats.org/package/2006/relationships"
    private const val RT = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val NA = "http://schemas.openxmlformats.org/drawingml/2006/main"
    private const val NP = "http://schemas.openxmlformats.org/presentationml/2006/main"
    private const val CT = "http://schemas.openxmlformats.org/package/2006/content-types"

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    private fun zip(out: File, parts: Map<String, ByteArray>) {
        ZipOutputStream(out.outputStream()).use { z -> parts.forEach { (n, d) -> z.putNextEntry(ZipEntry(n)); z.write(d); z.closeEntry() } }
    }
    private fun rels(vararg r: Triple<String, String, String>) =
        X + "<Relationships xmlns=\"$RN\">" + r.joinToString("") { "<Relationship Id=\"${it.first}\" Type=\"$RT/${it.second}\" Target=\"${it.third}\"/>" } + "</Relationships>"

    fun docx(pages: List<String>, out: File) {
        val body = pages.joinToString("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>") { t ->
            t.lines().joinToString("") { "<w:p><w:r><w:t xml:space=\"preserve\">${esc(it)}</w:t></w:r></w:p>" }
        }
        zip(out, linkedMapOf(
            "[Content_Types].xml" to (X + "<Types xmlns=\"$CT\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>").toByteArray(),
            "_rels/.rels" to rels(Triple("rId1", "officeDocument", "word/document.xml")).toByteArray(),
            "word/document.xml" to (X + "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>$body</w:body></w:document>").toByteArray()
        ))
    }

    private fun col(i: Int): String { var n = i; var s = ""; do { s = ('A' + n % 26) + s; n = n / 26 - 1 } while (n >= 0); return s }

    fun xlsx(rows: List<List<String>>, out: File) {
        val sheet = rows.mapIndexed { r, cells ->
            "<row r=\"${r + 1}\">" + cells.mapIndexed { c, v -> "<c r=\"${col(c)}${r + 1}\" t=\"inlineStr\"><is><t>${esc(v)}</t></is></c>" }.joinToString("") + "</row>"
        }.joinToString("")
        zip(out, linkedMapOf(
            "[Content_Types].xml" to (X + "<Types xmlns=\"$CT\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>").toByteArray(),
            "_rels/.rels" to rels(Triple("rId1", "officeDocument", "xl/workbook.xml")).toByteArray(),
            "xl/workbook.xml" to (X + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"$RT\"><sheets><sheet name=\"Sheet1\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>").toByteArray(),
            "xl/_rels/workbook.xml.rels" to rels(Triple("rId1", "worksheet", "worksheets/sheet1.xml")).toByteArray(),
            "xl/worksheets/sheet1.xml" to (X + "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>$sheet</sheetData></worksheet>").toByteArray()
        ))
    }

    private val GRP = "<p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/>"
    private val NS = "xmlns:a=\"$NA\" xmlns:r=\"$RT\" xmlns:p=\"$NP\""

    fun pptx(pages: List<Bitmap>, out: File) {
        val m = linkedMapOf<String, ByteArray>()
        val n = pages.size
        m["[Content_Types].xml"] = (X + "<Types xmlns=\"$CT\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Default Extension=\"jpeg\" ContentType=\"image/jpeg\"/>" +
            "<Override PartName=\"/ppt/presentation.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml\"/>" +
            "<Override PartName=\"/ppt/slideMasters/slideMaster1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml\"/>" +
            "<Override PartName=\"/ppt/slideLayouts/slideLayout1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml\"/>" +
            "<Override PartName=\"/ppt/theme/theme1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.theme+xml\"/>" +
            (1..n).joinToString("") { "<Override PartName=\"/ppt/slides/slide$it.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slide+xml\"/>" } + "</Types>").toByteArray()
        m["_rels/.rels"] = rels(Triple("rId1", "officeDocument", "ppt/presentation.xml")).toByteArray()
        m["ppt/presentation.xml"] = (X + "<p:presentation $NS><p:sldMasterIdLst><p:sldMasterId id=\"2147483648\" r:id=\"rId1\"/></p:sldMasterIdLst><p:sldIdLst>" +
            (1..n).joinToString("") { "<p:sldId id=\"${255 + it}\" r:id=\"rId${it + 1}\"/>" } + "</p:sldIdLst><p:sldSz cx=\"9144000\" cy=\"6858000\"/><p:notesSz cx=\"6858000\" cy=\"9144000\"/></p:presentation>").toByteArray()
        val pr = mutableListOf(Triple("rId1", "slideMaster", "slideMasters/slideMaster1.xml"))
        (1..n).forEach { pr.add(Triple("rId${it + 1}", "slide", "slides/slide$it.xml")) }
        m["ppt/_rels/presentation.xml.rels"] = rels(*pr.toTypedArray()).toByteArray()
        m["ppt/slideMasters/slideMaster1.xml"] = (X + "<p:sldMaster $NS><p:cSld><p:spTree>$GRP</p:spTree></p:cSld><p:clrMap bg1=\"lt1\" tx1=\"dk1\" bg2=\"lt2\" tx2=\"dk2\" accent1=\"accent1\" accent2=\"accent2\" accent3=\"accent3\" accent4=\"accent4\" accent5=\"accent5\" accent6=\"accent6\" hlink=\"hlink\" folHlink=\"folHlink\"/><p:sldLayoutIdLst><p:sldLayoutId id=\"2147483649\" r:id=\"rId1\"/></p:sldLayoutIdLst></p:sldMaster>").toByteArray()
        m["ppt/slideMasters/_rels/slideMaster1.xml.rels"] = rels(Triple("rId1", "slideLayout", "../slideLayouts/slideLayout1.xml"), Triple("rId2", "theme", "../theme/theme1.xml")).toByteArray()
        m["ppt/slideLayouts/slideLayout1.xml"] = (X + "<p:sldLayout $NS type=\"blank\"><p:cSld name=\"Blank\"><p:spTree>$GRP</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>").toByteArray()
        m["ppt/slideLayouts/_rels/slideLayout1.xml.rels"] = rels(Triple("rId1", "slideMaster", "../slideMasters/slideMaster1.xml")).toByteArray()
        val clr = listOf("dk1:000000", "lt1:FFFFFF", "dk2:44546A", "lt2:E7E6E6", "accent1:10B184", "accent2:0A7F9A", "accent3:A5A5A5", "accent4:FFC000", "accent5:5B9BD5", "accent6:70AD47", "hlink:0563C1", "folHlink:954F72")
            .joinToString("") { val (k, v) = it.split(":"); "<a:$k><a:srgbClr val=\"$v\"/></a:$k>" }
        val font = "<a:latin typeface=\"Arial\"/><a:ea typeface=\"\"/><a:cs typeface=\"\"/>"
        val fill = "<a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill>"
        val ln = "<a:ln w=\"9525\">$fill</a:ln>"
        m["ppt/theme/theme1.xml"] = (X + "<a:theme xmlns:a=\"$NA\" name=\"T\"><a:themeElements><a:clrScheme name=\"c\">$clr</a:clrScheme><a:fontScheme name=\"f\"><a:majorFont>$font</a:majorFont><a:minorFont>$font</a:minorFont></a:fontScheme>" +
            "<a:fmtScheme name=\"x\"><a:fillStyleLst>${fill.repeat(3)}</a:fillStyleLst><a:lnStyleLst>${ln.repeat(3)}</a:lnStyleLst><a:effectStyleLst>${"<a:effectStyle><a:effectLst/></a:effectStyle>".repeat(3)}</a:effectStyleLst><a:bgFillStyleLst>${fill.repeat(3)}</a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>").toByteArray()
        pages.forEachIndexed { i, b ->
            val k = i + 1
            val sc = minOf(9144000.0 / b.width, 6858000.0 / b.height)
            val cx = (b.width * sc).toLong(); val cy = (b.height * sc).toLong()
            val x = (9144000 - cx) / 2; val y = (6858000 - cy) / 2
            m["ppt/slides/slide$k.xml"] = (X + "<p:sld $NS><p:cSld><p:spTree>$GRP<p:pic><p:nvPicPr><p:cNvPr id=\"2\" name=\"img$k\"/><p:cNvPicPr/><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed=\"rId2\"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm><a:off x=\"$x\" y=\"$y\"/><a:ext cx=\"$cx\" cy=\"$cy\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></p:spPr></p:pic></p:spTree></p:cSld></p:sld>").toByteArray()
            m["ppt/slides/_rels/slide$k.xml.rels"] = rels(Triple("rId1", "slideLayout", "../slideLayouts/slideLayout1.xml"), Triple("rId2", "image", "../media/img$k.jpeg")).toByteArray()
            val bo = ByteArrayOutputStream(); Img.scale(b, 1600).compress(Bitmap.CompressFormat.JPEG, 85, bo)
            m["ppt/media/img$k.jpeg"] = bo.toByteArray()
        }
        zip(out, m)
    }

    // Impor Word/Excel/PPT -> teks polos
    fun readText(inp: InputStream, mime: String): String {
        val sb = StringBuilder(); val shared = mutableListOf<String>(); val sheets = mutableListOf<String>()
        ZipInputStream(inp).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val n = e.name
                val t = if (n == "word/document.xml" || n.startsWith("ppt/slides/slide") && n.endsWith(".xml") || n == "xl/sharedStrings.xml" || n.startsWith("xl/worksheets/sheet")) String(z.readBytes()) else null
                if (t != null) when {
                    n == "word/document.xml" -> sb.append(strip(t.replace("</w:p>", "\n")))
                    n.startsWith("ppt/slides") -> sb.append(strip(t.replace("</a:p>", "\n"))).append("\n\n")
                    n == "xl/sharedStrings.xml" -> Regex("<si>(.*?)</si>", RegexOption.DOT_MATCHES_ALL).findAll(t).forEach { shared.add(strip(it.groupValues[1])) }
                    else -> sheets.add(t)
                }
                e = z.nextEntry
            }
        }
        sheets.forEach { s ->
            Regex("<row[^>]*>(.*?)</row>", RegexOption.DOT_MATCHES_ALL).findAll(s).forEach { r ->
                sb.append(Regex("<c([^>]*)>(.*?)</c>", RegexOption.DOT_MATCHES_ALL).findAll(r.groupValues[1]).joinToString("\t") { c ->
                    val v = Regex("<v>(.*?)</v>").find(c.groupValues[2])?.groupValues?.get(1) ?: strip(c.groupValues[2])
                    if (c.groupValues[1].contains("t=\"s\"")) shared.getOrElse(v.toIntOrNull() ?: -1) { "" } else v
                }).append("\n")
            }
        }
        return sb.toString().ifBlank { "(Tidak ada teks)" }
    }
    private fun strip(s: String) = s.replace(Regex("<[^>]+>"), "").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
}
