package com.scanpro

import android.graphics.*
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.min

object Img {
    fun scale(b: Bitmap, mx: Int): Bitmap {
        val s = min(1f, mx / max(b.width, b.height).toFloat())
        return if (s >= 1f) b else Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true)
    }

    private fun cm(b: Bitmap, m: ColorMatrix): Bitmap {
        val o = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        Canvas(o).drawBitmap(b, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(m) })
        return o
    }

    fun filter(b: Bitmap, mode: String): Bitmap = when (mode) {
        "cerah" -> cm(b, ColorMatrix(floatArrayOf(1.25f, 0f, 0f, 0f, 15f, 0f, 1.25f, 0f, 0f, 15f, 0f, 0f, 1.25f, 0f, 15f, 0f, 0f, 0f, 1f, 0f)))
        "abu" -> cm(b, ColorMatrix().apply { setSaturation(0f) })
        "pulih" -> cm(b, ColorMatrix().apply {
            setSaturation(1.3f)
            postConcat(ColorMatrix(floatArrayOf(1.2f, 0f, 0f, 0f, -22f, 0f, 1.2f, 0f, 0f, -22f, 0f, 0f, 1.2f, 0f, -22f, 0f, 0f, 0f, 1f, 0f)))
        })
        "bersih" -> clean(b, false)
        "bw" -> clean(b, true)
        "tinta" -> noInk(b)
        else -> b
    }

    // Hapus Cerdas: bagi dengan estimasi latar -> latar jadi putih, bayangan hilang
    private fun clean(b: Bitmap, bw: Boolean): Bitmap {
        val w = b.width; val h = b.height
        val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        val small = Bitmap.createScaledBitmap(b, max(1, w / 8), max(1, h / 8), true)
        val up = Bitmap.createScaledBitmap(small, w, h, true)
        val bg = IntArray(w * h); up.getPixels(bg, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val p = px[i]; val q = bg[i]
            val gb = max(1.0, Color.red(q) * .3 + Color.green(q) * .59 + Color.blue(q) * .11)
            if (bw) {
                var v = (Color.red(p) * .3 + Color.green(p) * .59 + Color.blue(p) * .11) / gb * 235
                v = if (v > 200) 255.0 else if (v < 150) 0.0 else (v - 150) * 5.1
                val c = min(255, v.toInt()); px[i] = Color.rgb(c, c, c)
            } else {
                px[i] = Color.rgb(min(255, (Color.red(p) / gb * 235).toInt()), min(255, (Color.green(p) / gb * 235).toInt()), min(255, (Color.blue(p) / gb * 235).toInt()))
            }
        }
        val o = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); o.setPixels(px, 0, w, 0, 0, w, h); return o
    }

    // Hapus Penanda: hapus coretan berwarna (pulpen/stabilo), pertahankan teks hitam
    private fun noInk(b: Bitmap): Bitmap {
        val w = b.width; val h = b.height
        val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val r = Color.red(px[i]); val g = Color.green(px[i]); val bl = Color.blue(px[i])
            if (max(r, max(g, bl)) - min(r, min(g, bl)) > 55) px[i] = Color.WHITE
        }
        val o = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); o.setPixels(px, 0, w, 0, 0, w, h); return o
    }

    fun jpegRound(b: Bitmap, mx: Int, q: Int): Bitmap {
        val s = scale(b, mx); val bo = ByteArrayOutputStream()
        s.compress(Bitmap.CompressFormat.JPEG, q, bo)
        val a = bo.toByteArray(); return BitmapFactory.decodeByteArray(a, 0, a.size)
    }

    fun stamp(page: Bitmap, sig: Bitmap, fx: Float, fy: Float): Bitmap {
        val o = page.copy(Bitmap.Config.ARGB_8888, true)
        val w = o.width * .32f; val h = w * sig.height / sig.width
        Canvas(o).drawBitmap(sig, null, RectF(fx * o.width - w / 2, fy * o.height - h / 2, fx * o.width + w / 2, fy * o.height + h / 2), Paint(Paint.FILTER_BITMAP_FLAG))
        return o
    }

    fun sigBitmap(strokes: List<List<Pair<Float, Float>>>, w: Int, h: Int): Bitmap {
        val o = Bitmap.createBitmap(max(1, w), max(1, h), Bitmap.Config.ARGB_8888)
        val c = Canvas(o)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(10, 42, 108); strokeWidth = 6f; strokeCap = Paint.Cap.ROUND }
        strokes.forEach { s -> for (i in 1 until s.size) c.drawLine(s[i - 1].first, s[i - 1].second, s[i].first, s[i].second, p) }
        return o
    }

    fun watermark(b: Bitmap, t: String): Bitmap {
        val o = b.copy(Bitmap.Config.ARGB_8888, true); val c = Canvas(o)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 90, 90, 90); textSize = o.width / 9f; textAlign = Paint.Align.CENTER; isFakeBoldText = true }
        c.rotate(-35f, o.width / 2f, o.height / 2f); c.drawText(t, o.width / 2f, o.height / 2f, p); return o
    }

    fun timestamp(b: Bitmap, text: String): Bitmap {
        val o = b.copy(Bitmap.Config.ARGB_8888, true); val c = Canvas(o)
        val s = o.width / 26f
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 214, 74); textSize = s; typeface = Typeface.DEFAULT_BOLD; setShadowLayer(4f, 2f, 2f, Color.BLACK) }
        val lines = text.split("\n").filter { it.isNotBlank() }
        var y = o.height - s * 0.8f - (lines.size - 1) * s * 1.2f
        lines.forEach { c.drawText(it, s, y, p); y += s * 1.2f }
        return o
    }

    fun passPhoto(src: Bitmap, fg: Bitmap?, bg: Int?, wmm: Int, hmm: Int): Bitmap {
        val ratio = wmm.toFloat() / hmm
        var cw = src.width.toFloat(); var ch = cw / ratio
        if (ch > src.height) { ch = src.height.toFloat(); cw = ch * ratio }
        val sx = (src.width - cw) / 2; val sy = (src.height - ch) * .3f
        val o = Bitmap.createBitmap(wmm * 12, hmm * 12, Bitmap.Config.ARGB_8888); val c = Canvas(o)
        if (bg != null) c.drawColor(bg)
        val use = if (bg != null && fg != null) Bitmap.createScaledBitmap(fg, src.width, src.height, true) else src
        c.drawBitmap(use, Rect(sx.toInt(), sy.toInt(), (sx + cw).toInt(), (sy + ch).toInt()), Rect(0, 0, o.width, o.height), Paint(Paint.FILTER_BITMAP_FLAG))
        return o
    }

    fun sheet(photo: Bitmap, wmm: Int, hmm: Int): Bitmap {
        val o = Bitmap.createBitmap(1240, 1754, Bitmap.Config.ARGB_8888); val c = Canvas(o); c.drawColor(Color.WHITE)
        val pw = wmm * 5.9f; val ph = hmm * 5.9f; var y = 80f
        while (y + ph < 1700) { var x = 80f; while (x + pw < 1180) { c.drawBitmap(photo, null, RectF(x, y, x + pw, y + ph), Paint(Paint.FILTER_BITMAP_FLAG)); x += pw + 20 }; y += ph + 20 }
        return o
    }

    fun boxes(b: Bitmap, rs: List<Rect>): Bitmap {
        val o = b.copy(Bitmap.Config.ARGB_8888, true); val c = Canvas(o)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(16, 177, 132); style = Paint.Style.STROKE; strokeWidth = o.width / 150f }
        val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = o.width / 24f; setShadowLayer(4f, 0f, 0f, Color.BLACK) }
        rs.forEachIndexed { i, r -> c.drawRect(r, p); c.drawText("${i + 1}", r.left + 6f, r.top + t.textSize, t) }
        return o
    }
}
