package com.scanpro

import android.content.ContentValues
import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.provider.MediaStore
import android.text.StaticLayout
import android.text.TextPaint
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import java.io.File
import java.io.FileOutputStream

object Pdf {
    private inline fun <T> withR(f: File, block: (PdfRenderer) -> T): T {
        val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
        val r = PdfRenderer(pfd)
        try { return block(r) } finally { r.close(); pfd.close() }
    }

    fun count(f: File): Int = withR(f) { it.pageCount }

    private fun render(r: PdfRenderer, i: Int, w: Int): Bitmap {
        val p = r.openPage(i)
        try {
            val b = Bitmap.createBitmap(w, (w * p.height / p.width.toFloat()).toInt(), Bitmap.Config.ARGB_8888)
            b.eraseColor(Color.WHITE)
            p.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return b
        } finally { p.close() }
    }

    fun page(f: File, i: Int, w: Int): Bitmap = withR(f) { render(it, i, w) }
    fun all(f: File, w: Int = 1240): List<Bitmap> = withR(f) { r -> (0 until r.pageCount).map { render(r, it, w) } }

    fun build(pages: List<Bitmap>, out: File, maxPx: Int = 1700) {
        val d = PdfDocument()
        pages.forEachIndexed { i, src ->
            val b = Img.scale(src, maxPx)
            val w = 595; val h = (w * b.height / b.width.toFloat()).toInt()
            val p = d.startPage(PdfDocument.PageInfo.Builder(w, h, i + 1).create())
            p.canvas.drawBitmap(b, null, Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))
            d.finishPage(p)
        }
        FileOutputStream(out).use { d.writeTo(it) }; d.close()
    }

    fun textToPdf(text: String, out: File) {
        val d = PdfDocument()
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 12f; color = Color.BLACK }
        val W = 595; val H = 842; val m = 40
        val sl = StaticLayout.Builder.obtain(text, 0, text.length, tp, W - 2 * m).build()
        var y = 0; var n = 1
        do {
            val p = d.startPage(PdfDocument.PageInfo.Builder(W, H, n).create())
            p.canvas.translate(m.toFloat(), m.toFloat())
            p.canvas.clipRect(0f, 0f, (W - 2 * m).toFloat(), (H - 2 * m).toFloat())
            p.canvas.translate(0f, -y.toFloat()); sl.draw(p.canvas)
            d.finishPage(p); y += H - 2 * m; n++
        } while (y < sl.height)
        FileOutputStream(out).use { d.writeTo(it) }; d.close()
    }

    fun lock(ctx: Context, src: File, out: File, pw: String) {
        PDFBoxResourceLoader.init(ctx)
        PDDocument.load(src).use { d ->
            val sp = StandardProtectionPolicy(pw, pw, AccessPermission()); sp.encryptionKeyLength = 128
            d.protect(sp); d.save(out)
        }
    }

    fun saveGallery(ctx: Context, b: Bitmap, name: String) {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "$name.jpg"); put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ScanPro")
        }
        val u = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)!!
        ctx.contentResolver.openOutputStream(u)!!.use { b.compress(Bitmap.CompressFormat.JPEG, 92, it) }
    }

    class Printer(private val f: File) : PrintDocumentAdapter() {
        override fun onLayout(o: PrintAttributes?, n: PrintAttributes?, c: CancellationSignal?, cb: LayoutResultCallback, e: Bundle?) {
            cb.onLayoutFinished(PrintDocumentInfo.Builder(f.name).setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build(), true)
        }
        override fun onWrite(p: Array<out PageRange>?, d: ParcelFileDescriptor, c: CancellationSignal?, cb: WriteResultCallback) {
            f.inputStream().use { i -> FileOutputStream(d.fileDescriptor).use { o -> i.copyTo(o) } }
            cb.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
        }
    }
}
